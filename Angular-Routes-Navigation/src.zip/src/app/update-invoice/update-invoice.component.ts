import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-invoice',
  templateUrl: './update-invoice.component.html',
  styleUrls: ['./update-invoice.component.css']
})
export class UpdateInvoiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
